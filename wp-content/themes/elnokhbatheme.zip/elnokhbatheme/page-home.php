<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package saudi_woman
 */
?>

    <?php get_header(); ?>
    <div id="first_carousal" class="wow bounceInUp">
        <div class="owl-carousel owl-theme">
            <div class="item">
                <img src="pic/slide1.png" class="img-responsive">
            </div>
            <div class="item">
                <img src="pic/slide2.png" class="img-responsive">
            </div>
        </div>
    </div>
    <div id="who_us">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-xs-12 block_out  hvr-bob">
                    <div class="block block1">
                        <p class="title">من نحن</p>
                        <p class="text">
                            هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس
                        </p>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-12 block_out hvr-bob">
                    <div class="block">
                        <p class="title">الحدث سيبدأ بعد :</p>
                        <div class="countdown">
                            <div class="count">
                                <div class="sec">
                                    <b>20</b>
                                    <b>ثانية</b>
                                </div>
                                <div class="min">
                                    <b>60</b>
                                    <b>دقيقه</b>
                                </div>
                                <div class="hour">
                                    <b>22</b>
                                    <b>ساعة</b>
                                </div>
                                <div class="day">
                                    <b>1</b>
                                    <b>يوم</b>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="video">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <iframe src="https://www.youtube.com/embed/qWkewj8uo04" frameborder="0" allowfullscreen></iframe>
                </div>

            </div>
        </div>
    </div>
    <div id="why">
        <div class="container">
            <div class="row">
                <h3>ما الذي يدعوك للمشاركه؟</h3>
                <div>
                    <p class="why_text wow SlideInRight" data-wow-duration="2s" data-wow-delay=".1s">
                        هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص
                    </p>
                </div>
                <div>
                    <p class="why_text wow SlideInRight" data-wow-duration="2s" data-wow-delay=".3s">
                        هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة،د النص العربى، يمكنك أن تولد مثل هذا النص
                    </p>
                </div>
                <div>
                    <p class="why_text wow SlideInRight" data-wow-duration="2s" data-wow-delay=".5s">
                        هذا النص هو مثال لنص يمكن أن من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص
                    </p>
                </div>
                <div>
                    <p class="why_text wow SlideInRight" data-wow-duration="2s" data-wow-delay=".7s">
                        هذا النص هو مثال لنص يمكن أن من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص هذا النص هو مثال لنص يمكن أن من مولد النص العربى، حيث ذا النص هذا النص هو مثال لنص يمكن أن من مولد النص العربى، حيث ذا النص هذا النص هو مثال لنص يمكن أن من مولد النص العربى، حيث ذا النص

                    </p>
                </div>
                <div>
                    <p class="why_text wow SlideInRight" data-wow-duration="2s" data-wow-delay=".9s">
                        هذا النص هو مثال لنص يمكن أن يستبدل في هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div id="parteners" class="wow fadeinleftbig">
        <div class="container">
            <h1>الرعاة</h1>
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <a href="#"><img src="pic/sponsers/1.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/2.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/3.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/4.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/5.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/6.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/7.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/8.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/9.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
                <div class="item">
                    <a href="#"><img src="pic/sponsers/10.png" class="img-responsive hvr-pulse-grow"></a>
                </div>
            </div>
        </div>
    </div>



    <div id="halls">
        <div class="container">
            <h1>
                القاعات
            </h1>
            <div class="owl-carousel owl-theme">

                <div class="item">
                    <div class="row">
                        <h3>القاعه الأولي</h3>
                        <div class="col-sm-6 col-xs-12">
                            <div class="img_out">
                                <img class="img-responsive" src="pic/spon1.jpg">
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <ul class="hall_content">
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="item">
                    <div class="row">
                        <h3>القاعه الثانيه</h3>
                        <div class="col-sm-6 col-xs-12">
                            <div class="img_out">
                                <img class="img-responsive" src="pic/spon1.jpg">
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <ul class="hall_content">
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                                <li>
                                    <i class="fa fa-caret-left" aria-hidden="true"></i> البنوك ومكاتب التقسيط
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div id="sponsers_carousal" class="wow fadeindownbig">
        <div class="container">
            <h2>
                بفضل دعم هذه الشركات لرعاية المعرض
                <br> ترغب في أن تصبح راعي؟
                <a href="#">احجز مساحه</a>
            </h2>
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/1.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/2.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/3.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/4.png"></a>
                </div>
                <div class="item">
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/5.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/6.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/7.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/8.png"></a>
                </div>
                <div class="item">
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/9.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/10.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/1.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/2.png"></a>
                </div>
                <div class="item">
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/3.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/4.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/5.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/6.png"></a>
                </div>
                <div class="item">
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/3.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/4.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/5.png"></a>
                    <a href="#"><img class="img-responsive hvr-pulse-grow" src="pic/sponsers/6.png"></a>
                </div>
            </div>
        </div>
    </div>
    <!-- start board section -->
    <section class="BoardSection">
        <form id="BoardForm" action="" method="get">
            <div class="xs-y-scroll">
                <div class="FullBoard">
                    <div class="BoardHeader">
                        <h2>أقسام المعرض</h2>
                        <div class="headEle">
                            <p>بهو المعرض</p>
                            <p>المساحة</p>
                            <p>المستخدمة 55م<sup>2</sup></p>
                            <p>الحرة: 671م<sup>2</sup></p>
                            <p>نساء و عوائل</p>
                        </div>
                        <div class="headEle">
                            <p>جناح النخبة</p>
                            <p>المساحة</p>
                            <p>المستخدمة 525م<sup>2</sup></p>
                            <p>الحرة: 936.5م<sup>2</sup></p>
                            <p>نساء و عوائل</p>
                        </div>
                        <div class="headEle">
                            <p>جناح مصممات الازياء</p>
                            <p>المساحة</p>
                            <p>المستخدمة 111م<sup>2</sup></p>
                            <p>الحرة: 169م<sup>2</sup></p>
                            <p>نساء فقط</p>
                        </div>
                        <div class="headEle">
                            <p>جناح خبيرات التجميل</p>
                            <p>المساحة</p>
                            <p>المستخدمة 91م<sup>2</sup></p>
                            <p>الحرة: 189م<sup>2</sup></p>
                            <p>نساء فقط</p>
                        </div>
                    </div>
                    <div class="BoardContent">
                        <div class="part1">
                            <div class="form-ele">
                                <label class="main-place" for="1">1</label>
                                <input id="1" type="checkbox" name="board-place" value="1">
                            </div>
                        </div>
                        <div class="part2">
                            <div class="form-ele">
                                <label class="glory-place" for="2">2</label>
                                <input id="2" type="checkbox" name="board-place" value="2">
                            </div>
                        </div>
                        <div class="part3">
                            <div class="form-ele">
                                <label class="goldA-place" for="31">31</label>
                                <input id="31" type="checkbox" name="board-place" value="31">
                            </div>
                        </div>
                        <div class="part4">
                            <div class="form-ele">
                                <label class="goldA-place" for="32">32</label>
                                <input id="32" type="checkbox" name="board-place" value="32">
                            </div>
                        </div>
                        <div class="part5">
                            <div class="form-ele">
                                <label class="goldA-place" for="33">33</label>
                                <input id="33" type="checkbox" name="board-place" value="33">
                            </div>
                            <div class="form-ele">
                                <label class="goldA-place" for="34">34</label>
                                <input id="34" type="checkbox" name="board-place" value="34">
                            </div>
                        </div>
                        <div class="part6">
                            <div class="form-ele">
                                <label class="goldB-place" for="43">43</label>
                                <input id="43" type="checkbox" name="board-place" value="43">
                            </div>
                            <div class="form-ele">
                                <label class="goldB-place" for="44">44</label>
                                <input id="44" type="checkbox" name="board-place" value="44">
                            </div>
                            <div class="form-ele">
                                <label class="goldB-place" for="41">41</label>
                                <input id="41" type="checkbox" name="board-place" value="41">
                            </div>
                            <div class="form-ele">
                                <label class="goldB-place" for="42">42</label>
                                <input id="42" type="checkbox" name="board-place" value="42">
                            </div>
                        </div>
                        <div class="part7">
                            <div class="form-ele">
                                <label class="silver-place" for="51">51</label>
                                <input id="51" type="checkbox" name="board-place" value="51">
                            </div>
                            <div class="form-ele">
                                <label class="silver-place" for="52">52</label>
                                <input id="52" type="checkbox" name="board-place" value="52">
                            </div>
                        </div>
                        <div class="part8">
                            <div class="form-ele">
                                <label class="silver-place" for="53">53</label>
                                <input id="53" type="checkbox" name="board-place" value="53">
                            </div>
                            <div class="form-ele">
                                <label class="silver-place" for="54">54</label>
                                <input id="54" type="checkbox" name="board-place" value="54">
                            </div>
                        </div>
                        <div class="part9">
                            <div class="form-ele">
                                <label class="bronze-place" for="61">61</label>
                                <input id="61" type="checkbox" name="board-place" value="61">
                            </div>
                            <div class="form-ele">
                                <label class="bronze-place" for="62">62</label>
                                <input id="62" type="checkbox" name="board-place" value="62">
                            </div>
                        </div>
                        <div class="part10">
                            <div class="form-ele">
                                <label class="bronze-place" for="63">63</label>
                                <input id="63" type="checkbox" name="board-place" value="63">
                            </div>
                            <div class="form-ele">
                                <label class="bronze-place" for="64">64</label>
                                <input id="64" type="checkbox" name="board-place" value="64">
                            </div>
                        </div>
                        <div class="part11">
                            <div class="form-ele">
                                <label class="green-place" for="80">80</label>
                                <input id="80" type="checkbox" name="board-place" value="80">
                            </div>
                        </div>
                        <div class="part12">
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A1">A1</label>
                                <input id="A1" type="checkbox" name="board-place" value="A1">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A2">A2</label>
                                <input id="A2" type="checkbox" name="board-place" value="A2">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A3">A3</label>
                                <input id="A3" type="checkbox" name="board-place" value="A3">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A4">A4</label>
                                <input id="A4" type="checkbox" name="board-place" value="A4">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A5">A5</label>
                                <input id="A5" type="checkbox" name="board-place" value="A5">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A6">A6</label>
                                <input id="A6" type="checkbox" name="board-place" value="A6">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A7">A7</label>
                                <input id="A7" type="checkbox" name="board-place" value="A7">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A8">A8</label>
                                <input id="A8" type="checkbox" name="board-place" value="A8">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A9">A9</label>
                                <input id="A9" type="checkbox" name="board-place" value="A9">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="A10">A10</label>
                                <input id="A10" type="checkbox" name="board-place" value="A10">
                            </div>
                        </div>
                        <div class="part13">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A11">A11</label>
                                <input id="A11" type="checkbox" name="board-place" value="A11">
                            </div>
                        </div>
                        <div class="part14">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A22">A22</label>
                                <input id="A22" type="checkbox" name="board-place" value="A22">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A21">A21</label>
                                <input id="A21" type="checkbox" name="board-place" value="A21">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A20">A20</label>
                                <input id="A20" type="checkbox" name="board-place" value="A20">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A19">A19</label>
                                <input id="A19" type="checkbox" name="board-place" value="A19">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A18">A18</label>
                                <input id="A18" type="checkbox" name="board-place" value="A18">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A17">A17</label>
                                <input id="A17" type="checkbox" name="board-place" value="A17">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A16">A16</label>
                                <input id="A16" type="checkbox" name="board-place" value="A16">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A15">A15</label>
                                <input id="A15" type="checkbox" name="board-place" value="A15">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A14">A14</label>
                                <input id="A14" type="checkbox" name="board-place" value="A14">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A13">A13</label>
                                <input id="A13" type="checkbox" name="board-place" value="A13">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A12">A12</label>
                                <input id="A12" type="checkbox" name="board-place" value="A12">
                            </div>
                        </div>
                        <div class="part15">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A23">A23</label>
                                <input id="A23" type="checkbox" name="board-place" value="A23">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A24">A24</label>
                                <input id="A24" type="checkbox" name="board-place" value="A24">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A25">A25</label>
                                <input id="A25" type="checkbox" name="board-place" value="A25">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A26">A26</label>
                                <input id="A26" type="checkbox" name="board-place" value="A26">
                            </div>
                        </div>
                        <div class="part16">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A27">A27</label>
                                <input id="A27" type="checkbox" name="board-place" value="A27">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A28">A28</label>
                                <input id="A28" type="checkbox" name="board-place" value="A28">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A29">A29</label>
                                <input id="A29" type="checkbox" name="board-place" value="A29">
                            </div>
                        </div>
                        <div class="part17">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A30">A30</label>
                                <input id="A30" type="checkbox" name="board-place" value="A30">
                            </div>
                        </div>
                        <div class="part18">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A31">A31</label>
                                <input id="A31" type="checkbox" name="board-place" value="A31">
                            </div>
                        </div>
                        <div class="part19">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A38">A38</label>
                                <input id="A38" type="checkbox" name="board-place" value="A38">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A37">A37</label>
                                <input id="A37" type="checkbox" name="board-place" value="A37">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A36">A36</label>
                                <input id="A36" type="checkbox" name="board-place" value="A36">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A35">A35</label>
                                <input id="A35" type="checkbox" name="board-place" value="A35">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A34">A34</label>
                                <input id="A34" type="checkbox" name="board-place" value="A34">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A33">A33</label>
                                <input id="A33" type="checkbox" name="board-place" value="A33">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A32">A32</label>
                                <input id="A32" type="checkbox" name="board-place" value="A32">
                            </div>
                        </div>
                        <div class="part20">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A39">A39</label>
                                <input id="A39" type="checkbox" name="board-place" value="A39">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A40">A40</label>
                                <input id="A40" type="checkbox" name="board-place" value="A40">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A41">A41</label>
                                <input id="A41" type="checkbox" name="board-place" value="A41">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A42">A42</label>
                                <input id="A42" type="checkbox" name="board-place" value="A42">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A43">A43</label>
                                <input id="A43" type="checkbox" name="board-place" value="A43">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="A44">A44</label>
                                <input id="A44" type="checkbox" name="board-place" value="A44">
                            </div>
                        </div>
                        <div class="part21">
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B1">B1</label>
                                <input id="B1" type="checkbox" name="board-place" value="B1">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B2">B2</label>
                                <input id="B2" type="checkbox" name="board-place" value="B2">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B3">B3</label>
                                <input id="B3" type="checkbox" name="board-place" value="B3">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B4">B4</label>
                                <input id="B4" type="checkbox" name="board-place" value="B4">
                            </div>
                        </div>
                        <div class="part22">
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B8">B8</label>
                                <input id="B8" type="checkbox" name="board-place" value="B8">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B7">B7</label>
                                <input id="B7" type="checkbox" name="board-place" value="B7">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B6">B6</label>
                                <input id="B6" type="checkbox" name="board-place" value="B6">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="B5">B5</label>
                                <input id="B5" type="checkbox" name="board-place" value="B5">
                            </div>
                        </div>
                        <div class="part23">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="B9">B9</label>
                                <input id="B9" type="checkbox" name="board-place" value="B9">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="B10">B10</label>
                                <input id="B10" type="checkbox" name="board-place" value="B10">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="B11">B11</label>
                                <input id="B11" type="checkbox" name="board-place" value="B11">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="B12">B12</label>
                                <input id="B12" type="checkbox" name="board-place" value="B12">
                            </div>
                        </div>
                        <div class="part24">
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C1">C1</label>
                                <input id="C1" type="checkbox" name="board-place" value="C1">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C2">C2</label>
                                <input id="C2" type="checkbox" name="board-place" value="C2">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C3">C3</label>
                                <input id="C3" type="checkbox" name="board-place" value="C3">
                            </div>
                        </div>
                        <div class="part25">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="C4">C4</label>
                                <input id="C4" type="checkbox" name="board-place" value="C4">
                            </div>
                        </div>
                        <div class="part26">
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C9">C9</label>
                                <input id="C9" type="checkbox" name="board-place" value="C9">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C8">C8</label>
                                <input id="C8" type="checkbox" name="board-place" value="C8">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C7">C7</label>
                                <input id="C7" type="checkbox" name="board-place" value="C7">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C6">C6</label>
                                <input id="C6" type="checkbox" name="board-place" value="C6">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaV-place" for="C5">C5</label>
                                <input id="C5" type="checkbox" name="board-place" value="C5">
                            </div>
                        </div>
                        <div class="part27">
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="C10">C10</label>
                                <input id="C10" type="checkbox" name="board-place" value="C10">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="C11">C11</label>
                                <input id="C11" type="checkbox" name="board-place" value="C11">
                            </div>
                            <div class="form-ele">
                                <label class="nokhbaH-place" for="C12">C12</label>
                                <input id="C12" type="checkbox" name="board-place" value="C12">
                            </div>
                        </div>
                    </div>
                    <div class="BoardSubmitDiv">
                        <button id="BoardSubmitBtn" class="btn hvr-grow" type="submit">حجز</button>
                    </div>
                    <div class="BoardFooter">
                        <img src="pic/boardFooterBG.png" />
                    </div>
                </div>
            </div>
        </form>
    </section>
    <div id="form-popup">
        <div class="form-popup-content">
            <div class="close-btn"><i class="fa fa-times-circle-o" aria-hidden="true"></i></div>
            <h2 class="text-center">احجز مساحتك</h2>
            <h4>المساحات المحددة</h4>
            <table class="table table-hover places-table">
                <thead>
                    <tr>
                        <th class='hidden-xs'>نوع المساحة</th>
                        <th>رقم المساحة</th>
                        <th>السعر</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
            <form id="full-form" action="#" method="get">
                <h4>نموذج التسجيل الالكترونى</h4>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="adminName">اسم المسؤول</label>
                            <input id="adminName" type="text" class="form-control" placeholder="الكتابه باللغة الانجليزية فقط" name="adminName">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="userName">اسم المشترك</label>
                            <input id="userName" type="text" class="form-control" placeholder="الكتابه باللغة الانجليزية فقط" name="userName">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="job">المسمى الوظيفى</label>
                            <input id="job" type="text" class="form-control" placeholder="الكتابه باللغة الانجليزية فقط" name="job">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="email">البريد الإلكترونى</label>
                            <input id="email" type="text" class="form-control" placeholder="" name="email">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="tel">رقم الهاتف</label>
                            <input id="tel" type="tel" class="form-control" placeholder="" name="tel">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="phone">الجوال</label>
                            <input id="phone" type="tel" class="form-control" placeholder="" name="phone">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="userType">نوع العارض</label>
                            <select id="userType" class="form-control" name="userType">
                              <option value="company">شركة/مؤسسة - بسجل تجارى</option>
                              <option value="individual">فرد</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="equipType">نرغب بحجز مساحة</label>
                            <select id="equipType" class="form-control" name="equipType">
                              <option value="notEquip">مساحة بدون التجهيز</option>
                              <option value="equip">مساحة مع التجهيز</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn hvr-grow">اكمال الحجز</button>
                </div>
            </form>
        </div>
    </div>
    <!-- end board section -->


    <!-- sratr tickets reservation section -->
    <section class="ticketsReservation-section">
        <div class="container">
            <h2>حجز تذاكر الحضور</h2>
            <div class="row">
                <div class="col-sm-7 col-lg-6">
                    <div class="row">
                        <div class="col-sm-6 center-xs">
                            <div class="reserv-ele">
                                <div class="icon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                                <div class="ele-content">
                                    <p class="txt-h">تبدا</p>
                                    <p>Oct 18 2017 , 4pm</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 center-xs">
                            <div class="reserv-ele">
                                <div class="icon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                                <div class="ele-content">
                                    <p class="txt-h">تنتهى</p>
                                    <p>Oct 18 2017 , 4pm</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 center-xs">
                            <div class="reserv-ele">
                                <div class="icon"><i class="fa fa-money" aria-hidden="true"></i></div>
                                <div class="ele-content">
                                    <p class="txt-h">اسعار التذاكر</p>
                                    <p>50 - 300 ريال</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 center-xs">
                            <div class="reserv-ele">
                                <div class="icon"><i class="fa fa-car" aria-hidden="true"></i></div>
                                <div class="ele-content">
                                    <p class="txt-h">مكان الفعالية</p>
                                    <p><i class="fa fa-map-marker" aria-hidden="true"></i> فندق الانتركونتينتال - <br/> ملعب النخيل للقولف</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-5 col-lg-6">
                    <form id="ticketsReservation-form" action="" method="get">
                        <div class="form-group">
                            <label>الاسم بالكامل</label>
                            <input type="text" class="form-control" placeholder="الكتابه باللغة الانجليزية فقط" name="name">
                        </div>
                        <div class="form-group">
                            <label>البريد الالكترونى</label>
                            <input type="email" class="form-control" placeholder="الكتابه باللغة الانجليزية فقط" name="mail">
                        </div>
                        <div class="form-group">
                            <label for="ticketType">نوع التذكرة</label>
                            <select class="form-control" name="ticketType">
                              <option value="1">فرد واحد</option>
                              <option value="3">3 افراد</option>
                              <option value="5">5 افراد</option>
                            </select>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn hvr-grow">حجز تذكرة</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- end tickets reservation section -->

    <div id="sponser_program" class="wow fadeinupbig">
        <div class="container">
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <div class="img_out">
                        <img src="pic/spon1.jpg">
                    </div>
                    <p>الراعي الفضي</p>
                    <div class="price">
                        <span>300 ر.س</span>
                    </div>
                </div>
                <div class="item">
                    <div class="img_out">
                        <img src="pic/spon1.jpg">
                    </div>
                    <p>الراعي الفضي</p>
                    <div class="price">
                        <span>300 ر.س</span>
                    </div>
                </div>
                <div class="item">
                    <div class="img_out">
                        <img src="pic/spon1.jpg">
                    </div>
                    <p>الراعي الفضي</p>
                    <div class="price">
                        <span>300 ر.س</span>
                    </div>
                </div>
                <div class="item">
                    <div class="img_out">
                        <img src="pic/spon1.jpg">
                    </div>
                    <p>الراعي الفضي</p>
                    <div class="price">
                        <span>300 ر.س</span>
                    </div>
                </div>
                <div class="item">
                    <div class="img_out">
                        <img src="pic/spon1.jpg">
                    </div>
                    <p>الراعي الفضي</p>
                    <div class="price">
                        <span>300 ر.س</span>
                    </div>
                </div>
                <div class="item">
                    <div class="img_out">
                        <img src="pic/spon1.jpg">
                    </div>
                    <p>الراعي الفضي</p>
                    <div class="price">
                        <span>300 ر.س</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="media" class="wow fadeindownbig">
        <div class="container">
            <h3>يغطي المعرض اعلامياً عدة جهات منها</h3>
            <div class="row">
                <div class="owl-carousel owl-theme">
                    <div class="item">
                        <a href="#"><img src="pic/media/1.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/1.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/2.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/2.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/3.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/3.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/4.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/4.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/5.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/5.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/6.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/6.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/7.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/7.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/8.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/8.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/9.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/9.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="pic/media/10.png" class="img-responsive hvr-pulse-grow"></a>
                        <a href="#"><img src="pic/media/10.png" class="img-responsive hvr-pulse-grow"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <h3 class="loctaion">موقعنا</h3>
    <div id="map"></div>
    <script>
        function initMap() {
            var uluru = {
                lat: 24.6791009,
                lng: 46.6961055
            };
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 4,
                center: {
                    lat: 24.6791009,
                    lng: 46.6961055
                }
            });
            var marker = new google.maps.Marker({
                position: uluru,
                map: map,
                icon: 'pic/map.png'

            });
        }

    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBqKKnuKYWcB_1mwkQjWXS2_vvuVdsKn98&callback=initMap" async defer></script>


    <div id="contact" class="wow tada">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-xs-12">
                    <div class="row">
                        <div class="col-md-12 col-sm-6 col-xs-12">
                            <h3>
                                <i class="fa fa-map-marker" aria-hidden="true"></i> موقع الشركة</h3>
                            <ul>
                                <li>المملكة العربية السعودية</li>
                                <li>طريق الملك عبدالله</li>
                                <li>الرياض 1642</li>
                                <li> اوقات العمل من 8 صباحاص حتي 4 مساءً</li>
                            </ul>
                        </div>
                        <div class="col-md-12 col-sm-6 col-xs-12">
                            <h3>
                                <i class="fa fa-id-card" aria-hidden="true"></i> معلومات الاتصال</h3>
                            <ul>
                                <li>الرقم الموحد:55555555</li>
                                <li>جوال:557454548</li>
                                <li>بريد: dhjd@gmail</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xs-12">
                    <h3>
                        <i class="fa fa-envelope" aria-hidden="true"></i> اتصل بنا</h3>
                    <form>
                        <div class="form-group">
                            <label for="exampleInputName2">الاسم</label>
                            <input type="text" class="form-control" id="exampleInputName2" placeholder="الاسم">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">البريد الالكتروني</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="البريد الالكتروني">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName2">الجوال</label>
                            <input type="text" class="form-control" id="exampleInputName2" placeholder="الجوال">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName2">الموضوع</label>
                            <textarea class="form-control" rows="3" placeholder="الموضوع"></textarea>
                        </div>
                        <button type="submit" class="btn btn-default hvr-grow">ارسل</button>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="thank">
        <div class="text">
            <p>
                شكراً لكم زيارتكم موقعنا الالكتروني
                <br> لا تتردد في الانضمام معنا
            </p>
            <a href="#" class="btn hvr-grow">احجز مساحتك</a>
        </div>
    </div>
    <?php get_footer(); ?>
