(function ($) {
    //------------------------------ xs navbar open close 
    $('.xs-navbar-btn').click(function () {
        var right = $('.xs-navbar').css('right');
        $('.xs-navbar').animate({
            right: '0px'
        });
    });
    $('.xs-navbar-content > i').click(function () {
        $('.xs-navbar').animate({
            right: '-100%'
        });
    });
    $('.xs-navbar').click(function (e) {
        if (e.target.id == 'xs-navbar-id') {
            $('.xs-navbar').animate({
                right: '-100%'
            });
        }
    });
    $('.xs-navbar-content > ul > li > a').click(function () {
        $('.xs-navbar').animate({
            right: '-100%'
        });
    });
    //------------------------ end xs navbar
    //---------------------------------------------------------- start board -----------------------------------------------------*/
    //----------------- reset form when page load
    $('#BoardForm')[0].reset();
    //----------------- get places data
    var placeData = [
        {
            'name': '1',
            'status': 'off',
            'price': 20000,
            'type': 'راعى رئيسى'
        },
        {
            'name': '2',
            'status': 'on',
            'price': 17000,
            'type': 'راعى ماسى'
        },
        {
            'name': '31',
            'status': 'on',
            'price': 15000,
            'type': 'راعى ذهبى A'
        },
        {
            'name': '32',
            'status': 'on',
            'price': 15000,
            'type': 'راعى ذهبى A'
        },
        {
            'name': '33',
            'status': 'on',
            'price': 15000,
            'type': 'راعى ذهبى A'
        },
        {
            'name': '34',
            'status': 'on',
            'price': 15000,
            'type': 'راعى ذهبى A'
        },
        {
            'name': '41',
            'status': 'on',
            'price': 12000,
            'type': 'راعى ذهبى B'
        },
        {
            'name': '42',
            'status': 'off',
            'price': 12000,
            'type': 'راعى ذهبى B'
        },
        {
            'name': '43',
            'status': 'on',
            'price': 12000,
            'type': 'راعى ذهبى B'
        },
        {
            'name': '44',
            'status': 'on',
            'price': 12000,
            'type': 'راعى ذهبى B'
        },
        {
            'name': '51',
            'status': 'on',
            'price': 10000,
            'type': 'راعى فضي'
        },
        {
            'name': '52',
            'status': 'on',
            'price': 10000,
            'type': 'راعى فضي'
        },
        {
            'name': '53',
            'status': 'on',
            'price': 10000,
            'type': 'راعى فضي'
        },
        {
            'name': '54',
            'status': 'on',
            'price': 10000,
            'type': 'راعى فضي'
        },
        {
            'name': '61',
            'status': 'on',
            'price': 8000,
            'type': 'راعى برونزي'
        },
        {
            'name': '62',
            'status': 'on',
            'price': 8000,
            'type': 'راعى برونزي'
        },
        {
            'name': '63',
            'status': 'off',
            'price': 8000,
            'type': 'راعى برونزي'
        },
        {
            'name': '64',
            'status': 'on',
            'price': 8000,
            'type': 'راعى برونزي'
        },
        {
            'name': '80',
            'status': 'on',
            'price': 13000,
            'type': 'راعى الضيافة'
        },
        {
            'name': 'A1',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A2',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A3',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A4',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A5',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A6',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A7',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A8',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A9',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A10',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A11',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A12',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A13',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A14',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A15',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A16',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A17',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A18',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A19',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A20',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A21',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A22',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A23',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A24',
            'status': 'off',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A25',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A26',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A27',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A28',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A29',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A30',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A31',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A32',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A33',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A34',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A35',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A36',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A37',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A38',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A39',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A40',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A41',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A42',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A43',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'A44',
            'status': 'on',
            'price': 5000,
            'type': 'جناح النخبة'
        },
        {
            'name': 'B1',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B2',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B3',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B4',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B5',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B6',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B7',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B8',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B9',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B10',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B11',
            'status': 'on',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'B12',
            'status': 'off',
            'price': 5000,
            'type': 'جناح مصممات الازياء'
        },
        {
            'name': 'C1',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C2',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C3',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C4',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C5',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C6',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C7',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C8',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C9',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C10',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C11',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
        {
            'name': 'C12',
            'status': 'on',
            'price': 5000,
            'type': 'جناح خبيرات التجميل'
        },
    ];
    //----------------- set disable places
    disablePlaces(placeData);
    //------------------- when submit board form 
    $('#BoardSubmitBtn').click(function (e) {
        // prevent defult submit
        e.preventDefault();
        //get selected fields
        var selected_objects = getSelected();
        // if user select fields
        var total_cost = 0;
        if (selected_objects.length > 0) {
            //console.log(selected_objects);
            for (var m = 0; m < selected_objects.length; m++) {
                total_cost += selected_objects[m].price;
                $('.places-table tbody').append("<tr><td class='hidden-xs'>" + selected_objects[m].type + "</td><td>" + selected_objects[m].name + "</td><td>" + selected_objects[m].price + "</td></tr>");
                $('#full-form').prepend("<input type='hidden' name='selectedField' value='" + selected_objects[m].name + "'>");
            }
            $('.places-table').append("<thead id='cost-row-id'><tr><th>التكلفة الكلية</th><th class='hidden-xs'></th><th>" + total_cost + "</th></tr></thead>");
            $('#form-popup').fadeIn();
        }
        // if user doesn't select any fields
        else {
            alert("يجب تحديد مساحة او اكثر لاستكمال الحجز");
        }

    });
    /*--- start set disable places function ---*/
    function disablePlaces(placeData) {
        for (var n = 0; n < placeData.length; n++) {
            if (placeData[n].status == 'off') {
                var inputId = placeData[n].name;
                //set disable attr
                $("#" + inputId).attr("disabled", true);
                //set disable style
                $("#" + inputId).prev().css('cursor', 'not-allowed');
                $("#" + inputId).prev().css('background-color', 'red');
                $("#" + inputId).prev().css('border-color', 'red');
                $("#" + inputId).prev().css('opacity', '0.6');
                $("#" + inputId).prev().css('color', '#fff');
            }
        }
    }
    /*--- end set disable places function ---*/
    /*---- start get selected function ---*/
    function getSelected() {
        var form_data = $('#BoardForm').serialize();
        var places_arr = form_data.split('&');
        var selected_arr = [];
        if (places_arr[0] != "") {
            for (var i = 0; i < places_arr.length; i++) {
                var current_place = places_arr[i].split('=')[1];
                selected_arr.push(current_place);
            }
        }
        // get objects of selected names
        var selected_Objects = getFieldsObjects(selected_arr);

        return selected_Objects;
    }
    /*---- end get selected function --*/
    /*--- start get field object function ---*/
    function getFieldsObjects(fields_arr) {
        var fields_objects = [];
        for (var x = 0; x < fields_arr.length; x++) {
            var name = fields_arr[x];
            //console.log(name);
            for (var i = 0; i < placeData.length; i++) {
                if (name == placeData[i].name) {
                    fields_objects.push(placeData[i]);
                }
            }
        }
        return fields_objects;
    }
    /*--- end get field object function ---*/
    //---------------- change colors when check place
    $('.form-ele > input').change(function () {
        if ($(this).is(':checked')) {
            $(this).prev().css('background', '#2ECC71');
            $(this).prev().css('border-color', '#27AE60');
        } else {
            var place_class = $(this).prev().attr('class');
            if (place_class == 'd') {
                $(this).prev().css('background', '#003d61');
                $(this).prev().css('border-color', '#03113a');
            } else if (place_class == 'c') {
                $(this).prev().css('background', '#b5b9ba');
                $(this).prev().css('border-color', '#03113a');
            } else if (place_class == 'b') {
                $(this).prev().css('background', '#080145');
                $(this).prev().css('border-color', '#03113a');
            } else if (place_class == 'e') {
                $(this).prev().css('background', '#529ea4');
                $(this).prev().css('border-color', '#03113a');
            } else if (place_class == 'f') {
                $(this).prev().css('background', '#060134');
                $(this).prev().css('border-color', '#03113a');
            } else if (place_class == 'a') {
                $(this).prev().css('background', '#b00002');
                $(this).prev().css('border-color', '#e5afae');
            } else if (place_class == 'main-place') {
                $(this).prev().css('background', '#445968');
                $(this).prev().css('border-color', '#445968');
            } else if (place_class == 'glory-place') {
                $(this).prev().css('background', '#004a80');
                $(this).prev().css('border-color', '#004a80');
            } else if (place_class == 'goldA-place') {
                $(this).prev().css('background', '#fed142');
                $(this).prev().css('border-color', '#414346');
            } else if (place_class == 'goldB-place') {
                $(this).prev().css('background', '#252b2f');
                $(this).prev().css('border-color', '#4b4a49');
            } else if (place_class == 'silver-place') {
                $(this).prev().css('background', '#b7b7b7');
                $(this).prev().css('border-color', '#454545');
            } else if (place_class == 'bronze-place') {
                $(this).prev().css('background', '#754c24');
                $(this).prev().css('border-color', '#454545');
            } else if (place_class == 'green-place') {
                $(this).prev().css('background', '#007236');
                $(this).prev().css('border-color', '#252525');
            } else if (place_class == 'nokhbaV-place') {
                $(this).prev().css('background', '#b3a443');
                $(this).prev().css('border-color', '#252525');
            } else if (place_class == 'nokhbaH-place') {
                $(this).prev().css('background', '#b3a443');
                $(this).prev().css('border-color', '#252525');
            }
        }
    });
    //------------------- close form-popup
    $('.close-btn i').click(function () {
        $('#form-popup').fadeOut(function () {
            $('.places-table tbody').html('');
            $('#cost-row-id').remove();
        });
    });
    $(document).click(function (e) {
        if ($(e.target).attr('id') == "form-popup") {
            $('#form-popup').fadeOut(function () {
                $('.places-table tbody').html('');
                $('#cost-row-id').remove();
            });
        }
    });
    /*----------------------------------------------------- end board --------------------------------------------------------------*/
    $(".small_menu").hide();

    $(".click").mouseover(function () {
        $(".small_menu").slideDown('slow');
    });

    $(".hoverli").mouseleave(function () {
        $(".small_menu").slideUp('slow');
    });

    $('#first_carousal .owl-carousel').owlCarousel({
        loop: true,
        rtl: true,
        nav: true,
        dots: false,
        navText: ['<i class="fa fa-chevron-right"></i>', '<i class="fa fa-chevron-left"></i>'],
        margin: 10,
        animateOut: 'fadeOutLeft',
        animateIn: 'fadeInLeft',
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            600: {
                items: 1,
                nav: false
            },
            900: {
                items: 1,
                nav: true
            },
            1000: {
                items: 1,
                nav: true,
                loop: false
            }
        }
    });

    $('#parteners .owl-carousel').owlCarousel({
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: false,
        autoplaySpeed: 500,
        rtl: true,
        nav: true,
        dots: false,
        navText: ["<i class='fa fa-angle-right'></i> ", "<i class='fa fa-angle-left'></i>"],
        margin: 10,
        loop: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            600: {
                items: 2,
                nav: false
            },
            767: {
                items: 3,
                nav: false
            },
            900: {
                items: 6,
                nav: true
            },
            1000: {
                items: 4,
                nav: true,
                loop: true
            }
        }
    });

    $('#sponsers_carousal .owl-carousel').owlCarousel({
        autoplay: true,
        autoplayTimeout: 1500,
        autoplayHoverPause: false,
        autoplaySpeed: 1000,
        rtl: true,
        nav: true,
        dots: false,
        navText: ["<i class='fa fa-angle-right'></i> ", "<i class='fa fa-angle-left'></i>"],
        margin: 170,
        loop: true,
        center: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            600: {
                items: 2,
                nav: false
            },
            767: {
                items: 3,
                nav: false
            },
            900: {
                items: 3,
                nav: true
            },
            1000: {
                items: 4,
                nav: true,
                loop: true
            }
        }
    });

    $('#sponser_program .owl-carousel').owlCarousel({
        loop: true,
        rtl: true,
        nav: true,
        dots: false,
        navText: ['<i class="fa fa-chevron-right"></i>', '<i class="fa fa-chevron-left"></i>'],
        margin: 40,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            400: {
                items: 2,
                nav: false
            },
            600: {
                items: 3,
                nav: false
            },
            1000: {
                items: 3,
                nav: true,
                loop: true
            }
        }
    });

    $('#media .owl-carousel').owlCarousel({
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: false,
        autoplaySpeed: 500,
        rtl: true,
        nav: false,
        dots: true,
        navText: ["<i class='fa fa-angle-right'></i> ", "<i class='fa fa-angle-left'></i>"],
        margin: 10,
        loop: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 2,
            },
            767: {
                items: 3,
            },
            900: {
                items: 6,
            },
            1000: {
                items: 4,
                loop: true
            }
        }
    });


    $('#halls .owl-carousel').owlCarousel({
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: false,
        autoplaySpeed: 500,
        rtl: true,
        nav: true,
        dots: false,
        navText: ["<i class='fa fa-angle-right'></i> ", "<i class='fa fa-angle-left'></i>"],
        margin: 10,
        loop: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,
            },
            767: {
                items: 1,
            },
            900: {
                items: 1,
            },
            1000: {
                items: 1,
                loop: true
            }
        }
    });


    $(".home").click(function () {
        $('html, body').animate({
            scrollTop: $("#nav_bar").offset().top
        }, 2000);
    });
    $(".intro").click(function () {
        $('html, body').animate({
            scrollTop: $("#first_carousal").offset().top
        }, 2000);
    });
    $(".who_us").click(function () {
        $('html, body').animate({
            scrollTop: $("#who_us").offset().top
        }, 2000);
    });
    $(".vision").click(function () {
        $('html, body').animate({
            scrollTop: $("#video").offset().top
        }, 2000);
    });
    $(".whyp").click(function () {
        $('html, body').animate({
            scrollTop: $("#why").offset().top
        }, 2000);
    });
    $(".parteners").click(function () {
        $('html, body').animate({
            scrollTop: $("#parteners").offset().top
        }, 2000);
    });
    $(".locationn").click(function () {
        $('html, body').animate({
            scrollTop: $("#contact").offset().top
        }, 2000);
    });
    $(".mapp").click(function () {
        $('html, body').animate({
            scrollTop: $("#map").offset().top
        }, 2000);
    });


    new WOW().init();
})(jQuery);
